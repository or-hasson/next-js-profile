import BasePage from "../components/BasePage";
import BaseLayout from "../components/layouts/BaseLayout";


const Blogs = () => {
    return (
        <BaseLayout>
            <BasePage>
      <h1> I am Blogs Page </h1>
            </BasePage>
        </BaseLayout>
    )
}

export default Blogs;