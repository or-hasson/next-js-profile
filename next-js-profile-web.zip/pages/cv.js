import BasePage from "../components/BasePage";
import BaseLayout from "../components/layouts/BaseLayout";


const Cv = () => {
    return (
        <BaseLayout>
            <BasePage>
      <h1> I am Cv Page </h1>
            </BasePage>
        </BaseLayout>
    )
}

export default Cv;